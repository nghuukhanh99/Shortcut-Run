﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Bot1Move : MonoBehaviour
{
    public GameObject[] WayPoints;
    NavMeshAgent Agent;
    public float speedRunning;
    void Start()
    {
        Agent = this.GetComponent<NavMeshAgent>();

        int direction = Random.Range(0, WayPoints.Length);

        Agent.SetDestination(WayPoints[direction].transform.position);

    
    }

    
    void Update()
    {
        transform.Translate(Vector3.forward * Time.smoothDeltaTime * speedRunning);

        if (Agent.remainingDistance < 0.5f)
        {
            int direction = Random.Range(0, WayPoints.Length);

            Agent.SetDestination(WayPoints[direction].transform.position);
        }
    }
}
