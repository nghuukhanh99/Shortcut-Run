﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CancelRotation : MonoBehaviour
{
    public GameObject CancelRotationObject;

    // Update is called once per frame
    void Update()
    {
        this.transform.rotation = CancelRotationObject.transform.rotation;
    }
}
