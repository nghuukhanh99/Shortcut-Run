﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BotCollision : MonoBehaviour
{
    private void OnCollisionEnter(Collision other)
    {

        if (other.gameObject.tag == "Jump")
        {
            Bot1Ctrl.Instance.rb.AddForce(Bot1Ctrl.Instance.jumpVector * Bot1Ctrl.Instance.jumpForce, ForceMode.Impulse);

            //isOnGround = false;

            //inTheAir = true;

            Debug.Log("Jump");
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Finish")
        {
            Time.timeScale = 0;


        }
    }


    private void OnCollisionStay(Collision other)
    {
        if (other.gameObject.CompareTag("Ground"))
        {
            Bot1Ctrl.Instance.isOnGround = true;

            Debug.Log("Ok");
        }

        if (other.gameObject.tag != "Plank" && other.gameObject.tag != "Ground" && other.gameObject.tag == "Trigger Spawn Plank")
        {
            Bot1Ctrl.Instance.isOnGround = false;

            Bot1Ctrl.Instance.SpawnPlankUnderPlayer();
        }


    }
}
