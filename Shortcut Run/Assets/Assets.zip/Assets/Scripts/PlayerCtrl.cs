﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerCtrl : MonoBehaviour
{
    public static PlayerCtrl Instance;

    public float speedRunning;

    public float speedRotate;

    public GameObject WoodPlankToSpawn;

    public GameObject carryPlankPoint;

    public Vector3 UpPosPlank = new Vector3(0, 0.01f, 0);

    public GameObject CancelRotationObject;

    public Rigidbody rb;

    public GameObject PlankPlayerMove;

    public GameObject PlayerPos;

    public List<GameObject> plankNumber = new List<GameObject>();

    Vector3 upPosPlankMove = new Vector3(0, 0, 0.5f);

    public int maxPlankSpawn;

    public int plankCount = 0;

    public List<GameObject> PlankMoveSpawn;

    public Vector3 upPosPlank = new Vector3(0.150f, 0, 0.1f);

    public GameObject TriggerSpawnPlank;

    public Vector3 jumpVector;

    public float jumpForce = 0.1f;

    public bool isOnGround;

    public bool inTheAir;

    public GameObject FinishPoint;

    public TextMeshProUGUI GoldNumber;

    public int Gold = 0;
    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
    }
    void Start()
    {
        rb = GetComponent<Rigidbody>();

        jumpVector = new Vector3(0.0f, 10.0f, 0.0f);

        inTheAir = false;
    }


    private void Update()
    {
        MoveCharacter();

    }   

    public void MoveCharacter()
    {

        transform.Translate(Vector3.forward * Time.smoothDeltaTime * speedRunning);

        if (Input.GetMouseButton(0))
        {
            float mouseX = Input.GetAxisRaw("Mouse X");

            transform.Rotate(0, mouseX * Time.smoothDeltaTime * speedRotate, 0);
        }

    }
    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Plank"))
        {
            other.gameObject.SetActive(false);

            GameObject woodPlankSpawn = (GameObject)Instantiate(WoodPlankToSpawn, carryPlankPoint.transform.position, Quaternion.identity); // Spawn Wood

            woodPlankSpawn.transform.parent = carryPlankPoint.transform;

            woodPlankSpawn.transform.rotation = CancelRotationObject.transform.rotation;

            for (int i = 0; i < plankNumber.Count; i++) //Pickup and stack Wood plank 
            {
                plankNumber[i].transform.position = new Vector3(plankNumber[i].transform.position.x, plankNumber[i].transform.position.y + UpPosPlank.y, plankNumber[i].transform.position.z);
            }

            plankNumber.Add(woodPlankSpawn);

        }


        
    }

    

    public void SpawnPlankUnderPlayer()
    {

        if (plankCount >= plankNumber.Count)
        {
            TriggerSpawnPlank.SetActive(false);

            return;
        }


        GameObject plankMove = Instantiate(PlankPlayerMove, PlayerPos.transform.position, PlayerPos.transform.rotation);

        Destroy(plankNumber[plankNumber.Count - 1].gameObject);

        plankNumber.RemoveAt(plankNumber.Count - 1);
       
        

        PlankMoveSpawn.Add(plankMove);

        Destroy(plankMove, 1.5f);


    }

    

}
