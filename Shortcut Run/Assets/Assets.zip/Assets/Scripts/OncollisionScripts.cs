﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OncollisionScripts : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update() { 
        
    }

    private void OnCollisionEnter(Collision other)
    {
        
        if (other.gameObject.tag == "Jump")
        {
            PlayerCtrl.Instance.rb.AddForce(PlayerCtrl.Instance.jumpVector * PlayerCtrl.Instance.jumpForce, ForceMode.Impulse);

            //isOnGround = false;

            //inTheAir = true;

            Debug.Log("Jump");

        }

        if (other.gameObject.tag == "X2")
        {
            PlayerCtrl.Instance.Gold *= 2;
            PlayerCtrl.Instance.GoldNumber.text = PlayerCtrl.Instance.Gold.ToString();
        }
        if (other.gameObject.tag == "X3")
        {
            PlayerCtrl.Instance.Gold *= 3;
            PlayerCtrl.Instance.GoldNumber.text = PlayerCtrl.Instance.Gold.ToString();
        }
        if (other.gameObject.tag == "X4")
        {
            PlayerCtrl.Instance.Gold *= 4;
            PlayerCtrl.Instance.GoldNumber.text = PlayerCtrl.Instance.Gold.ToString();
        }
        if (other.gameObject.tag == "X5")
        {
            PlayerCtrl.Instance.Gold *= 5;
            PlayerCtrl.Instance.GoldNumber.text = PlayerCtrl.Instance.Gold.ToString();
        }
        if (other.gameObject.tag == "X10")
        {
            PlayerCtrl.Instance.Gold *= 10;
            PlayerCtrl.Instance.GoldNumber.text = PlayerCtrl.Instance.Gold.ToString();
        }
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Finish")
        {
            PlayerCtrl.Instance.isOnGround = false;

            PlayerCtrl.Instance.FinishPoint.SetActive(true);

            PlayerCtrl.Instance.SpawnPlankUnderPlayer();

            PlayerCtrl.Instance.Gold += 100;

            PlayerCtrl.Instance.GoldNumber.text = PlayerCtrl.Instance.Gold.ToString();

            Debug.Log("Ok");

        }

        
    }

    

    private void OnCollisionStay(Collision other)
    {
        if (other.gameObject.CompareTag("Ground"))
        {
            PlayerCtrl.Instance.isOnGround = true;

            Debug.Log("Ok");
        }

        if (other.gameObject.tag != "Plank" && other.gameObject.tag != "Ground" && other.gameObject.tag == "Trigger Spawn Plank")
        {
            PlayerCtrl.Instance.isOnGround = false;

            PlayerCtrl.Instance.SpawnPlankUnderPlayer();
        }

        
    }
}
